Starter code for Unit 7 Lab: Bet 1.0
